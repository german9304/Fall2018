

# Value of discovered tmin: 44083498

# Approached I used for the search of tmin
  
  My first app 